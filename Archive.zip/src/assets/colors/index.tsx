export const COLOR_PRIMARY = '#ff2d55';
export const COLOR_DIVIDER = '#67637033';
export const COLOR_TEXT = '#fff';