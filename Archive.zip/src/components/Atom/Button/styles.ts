import { COLOR_TEXT } from '../../../assets/colors';

export const buttonStyle: React.CSSProperties = {
  color: COLOR_TEXT,
  padding: '14px 40px',
  fontWeight: 600
};